TMH Device Inventory Report Generator (Offline)
==============================================

This tool lets you upload an Excel file exported from Microsoft Intune (OData feed) and generates a printable, TMH-branded device inventory report — all offline, in your browser.

USAGE INSTRUCTIONS
------------------
1. Open report-generator.html in your web browser (Chrome, Edge, Firefox, Safari).
2. Click "Choose Excel File" and select your Intune OData export (.xlsx).
3. If your file has multiple sheets, select the correct one from the dropdown.
4. The report will generate automatically. Use the Export buttons to save as PDF or HTML, or print directly.

REQUIRED COLUMNS
----------------
Your Excel file must include these columns:
- operatingSystem
- model
- deviceCategoryDisplayName
- complianceState
- lastSyncDateTime

If any are missing, the tool will show an error and list the missing columns.

TROUBLESHOOTING
---------------
- If you see "Waiting for upload…", no file has been selected yet.
- If you see "Parsed X devices successfully", your file is valid and the report is ready.
- If you see a red error, check your Excel file for the required columns above.
- If you have multiple sheets, make sure to select the correct one.

SUPPORT
-------
For questions or help, contact TMH IT Asset Management. 